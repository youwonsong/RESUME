package hw1;

public class Backpacker {
		private int currentFunds;
		private City currentCity;
		private String journal;
		private int stayNight;
		private int postcardCount;
		private int numDays;
		private int numDaysCount;
	public static final int SYMPATHY_FACTOR = 30;
	
	public Backpacker(int initialFunds, City initialCity) {
		currentFunds = initialFunds;
		currentCity = new City(initialCity.getCityName(), initialCity.hostelCost());
		journal = initialCity.getCityName()+"(start)";
		stayNight = 0;
	}
	public String getCurrentCity() {
		return currentCity.getCityName();
	}
	public int getCurrentMoney() {
		return currentFunds;
	}
	public String getJournal() {
		return journal;
	}
	public boolean isSOL() {
		if(currentFunds<0.05) {
			return true;
		}
		else {
			return false;
		}
		
	}
	public int getNightsInStation() {
		numDays = stayNight - currentCity.nightsStay(currentFunds);
		numDaysCount = 0;
		numDays = 2;
		numDaysCount = numDaysCount + numDays;
		if(numDays < 0) {
			numDays = 0;
		}else {
			return numDaysCount;
		}
			return numDaysCount;
	}
	public void visit(City c, int numNights) {
		currentCity = new City(c.getCityName(),c.hostelCost());
		stayNight = numNights;
		journal = journal +"," + currentCity.getCityName()+"("+ numNights + ")";
			if(currentFunds - stayNight * currentCity.hostelCost() < 0) {
				currentFunds = currentFunds - currentCity.hostelCost() *(currentCity.nightsStay(currentFunds) - stayNight); 
			}
			currentFunds = currentFunds - stayNight * currentCity.hostelCost();
		}
	
	public void sendPostcardsHome(int howMany) {
		
		if(howMany > currentFunds/0.05) {
			howMany = (int)(currentFunds/0.05);
			postcardCount = postcardCount + howMany;
		}
		else {
			currentFunds = currentFunds - (int)(howMany * 0.05);
			postcardCount = postcardCount + howMany;
		}
	}
	public void callHomeForMoney() {
		currentFunds = currentFunds +(postcardCount * SYMPATHY_FACTOR); 
		postcardCount = 0;
	}


}