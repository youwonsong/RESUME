	package hw1;	
	import java.lang.Math;
	public class City{ //City class
		private String city;
		private int moneycost;
	public final static double POSTCARD_COST=0.05; //constants
	public City(String name,int cost){//constructor of class
			city=name;
			moneycost=cost;
	}
	public String getCityName(){//method returns city name
			return city;
	}
	public int hostelCost(){ ///method returns hostel cost
			return moneycost;
	}
	public int postcardCost(){ //returns total post card cost
			return (int)(Math.round(moneycost*POSTCARD_COST));
	}
	public int nightsStay(int moneyAvailable){//returns number of nights
			int temp = 0;
			temp=(int)moneyAvailable/moneycost;
			return temp;
	} 
	public int numPostcards(int moneyAvailable){//returns number of post cards
			int temp;
			temp= (int)moneyAvailable/4;
			return temp;
	}
}
