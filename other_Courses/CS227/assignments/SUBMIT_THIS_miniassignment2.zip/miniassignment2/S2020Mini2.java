package miniassignment2;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 * <h1>Miniassignment 2</h1> COM S 227 <br>
 * Spring 2020 <br>
 * 40 points
 * <p>
 * Due: Wednesday, March 25, 11:59 pm (midnight) <br>
 * 5% bonus for submitting 1 day early (by 11:59 pm March 24) <br>
 * 10% penalty for submitting 1 day late (by 11:59 pm March 26) <br>
 * No submissions accepted after March 26, 11:59 pm
 *
 * <p>
 * <b>This assignment is to be done on your own. See the Academic Dishonesty
 * policy in the syllabus, http://www.cs.iastate.edu/~cs227/syllabus.html#ad ,
 * for details.</b>
 *
 * <p>
 * <b>You will not be able to submit your work unless you have completed the
 * Academic Dishonesty policy acknowledgement on the Homework page on Canvas.
 * Please do this right away.</b>
 *
 * <p>
 * <b>If you need help, see your instructor or one of the TAs. Lots of help is
 * also available through the Piazza discussions.</b>
 *
 * <p>
 * <b>Note: This is a miniassignment and the grading is automated. If you do not
 * submit it correctly, you will receive at most half credit.</b>
 *
 * <h2>Overview</h2>
 *
 * This is a short set of practice problems involving arrays. You will write six
 * methods for the class <em>S2020Mini2</em>. All of the methods are static, so
 * your class will not have any instance variables (or any static variables, for
 * that matter). There is a constructor, but it is declared private so the class
 * cannot be instantiated, e.g., declare your constructor <em>private
 * S2020Mini2(){}</em>.
 *
 * <h2>Advice</h2>
 *
 * Before you write any code for a method, work through the problem with a
 * pencil and paper on a few concrete examples. Make yourself write everything
 * down; in particular, write down things that you need to remember from one
 * step to the next (such as indices, or values from a previous step). Try to
 * explain what you are doing in words. Write your algorithm in pseudocode.
 *
 * <p>
 * Another key problem-solving strategy is to try solving part of the problem,
 * or solving a related, simpler problem.
 *
 * <h2>My code's not working!!</h2>
 *
 * Developing loops can be hard. If you are getting errors, a good idea is to
 * take a simple concrete example, and trace execution of your code by hand (as
 * illustrated in section 6.2 of the text) to see if the code is doing what you
 * want it to do. You can also trace what's happening in the code by temporarily
 * inserting println statements to check whether variables are getting updated
 * in the way you expect. (Remember to remove the extra println's when you're
 * done!)
 *
 * <p>
 * Overall, the best way to trace through code with the debugger, as we are
 * practicing in Lab 6. Learn to use the debugger effectively, and it will be a
 * lifelong friend.
 *
 * <p>
 * Always remember: one of the wonderful things about programming is that within
 * the world of your own code, you have absolute, godlike power. If the code
 * isn't doing what you want it to do, you can decide what you really want, and
 * make it so. You are in complete control!
 *
 * <p>
 * (If you are not sure what you want the code to do, well, that's a different
 * problem. Go back to the "Advice" section.)
 *
 * <h2>Documentation and style</h2>
 *
 * Since this is a miniassignment, the grading is automated and in most cases we
 * will not be reading your code. Therefore, there are no specific documentation
 * and style requirements. However, writing a brief descriptive comment for each
 * method will help you clarify what it is you are trying to do.
 *
 * <h2>If you have questions</h2>
 *
 * For questions, please see the Piazza Q &amp; A pages and click on the folder
 * miniassignment2. If you don't find your question answered, then create a new
 * post with your question. Try to state the question or topic clearly in the
 * title of your post, and attach the tag miniassignment2. But remember, do not
 * post any source code for the classes that are to be turned in. It is fine to
 * post source code for general Java examples that are not being turned in. (In
 * the Piazza editor, use the button labeled "pre" to have Java code formatted
 * the way you typed it.)
 *
 * <p>
 * If you have a question that absolutely cannot be asked without showing part
 * of your source code, make the post "private" so that only the instructors and
 * TAs can see it. Be sure you have stated a specific question; vague requests
 * of the form "read all my code and tell me what's wrong with it" will
 * generally be ignored.
 *
 * <p>
 * Of course, the instructors and TAs are always available to help you. See the
 * Office Hours section of the syllabus to find a time that is convenient for
 * you. We do our best to answer every question carefully, short of actually
 * writing your code for you, but it would be unfair for the staff to fully
 * review your assignment in detail before it is turned in.
 *
 * <p>
 * Any posts from the instructors on Piazza that are labeled "Official
 * Clarification" are considered to be part of the spec, and you may lose points
 * if you ignore them. Such posts will always be placed in the Announcements
 * section of the course page in addition to the Q &amp; A page. (We promise
 * that no official clarifications will be posted within 24 hours of the due
 * date.)
 */
public class S2020Mini2 {
	private S2020Mini2() {
	}

	/**
	 * Names for each of the four cardinal directions on a plane. Used in
	 * <em>langtonsAnt</em>.
	 */
	public enum Direction {
		UP, LEFT, DOWN, RIGHT
	}

	/**
	 * Calculates the coefficients of the expansion of the binomial expression (x +
	 * y)<sup>n</sup>. Coefficients are calculated by expanding Pascal's Triangle
	 * (see <a href=
	 * "https://upload.wikimedia.org/wikipedia/commons/0/0d/PascalTriangleAnimated2.gif">this
	 * animated gif</a> from Wikipedia).
	 *
	 * <p>
	 * <b>Coeffients must be calculated by expanding Pascal's Triangle! No other
	 * methods of calculating binomial coefficients will be accepted!</b>
	 *
	 * <p>
	 * For instance, <em>binomialCoefficients(7)</em> returns [1, 7, 21, 35, 35, 21,
	 * 7, 1]
	 *
	 * @param n The degree of the polynomial
	 * @return An array of <em>n</em> + 1 terms containing the
	 *         <em>n</em><sup>th</sup> degree binomial coefficients.
	 */
	public static int[] binomialCoefficients(int n) {

		int[] A = new int[n + 1];
		int[][] C = new int[n + 1][n + 1];
		C[0][0] = 1;
		for (int i = 1; i <= n; ++i) {
			C[i][0] = C[i][i] = 1;
			for (int k = 1; k < i; ++k) {
				C[i][k] = C[i - 1][k - 1] + C[i - 1][k];
			}
		}
		for (int i = n; i == n; i++) {
			for (int j = 0; j <= n; j++) {
				A[j] = C[i][j];
			}
		}
		return A;
	}

	/**
	 * Factors <em>n</em> and return the factors in an array. All factors are
	 * arranged in non-descending order in the returned array. Note that a prime
	 * number is its own factor; this is true of composite numbers, as well, but not
	 * apropos here.
	 *
	 * <p>
	 * For instance, <em>factor(413423478)</em> returns [2, 3, 3, 13, 29, 60923]
	 *
	 * @param n The number to be factored
	 * @return An array of length <em>number of prime factors of n</em> containing
	 *         each of the factors in non-decreasing order.
	 */
	public static int[] factorization(int n) {
		int count = 0;
		int num = n;
		for (int i = 2; i <= n; i++) {
			while (n % i == 0) {
				++count;
				n /= i;
			}
		}
		int[] list = new int[count];
		int index = 0;
		n = num;
		for (int i = 2; i <= n; i++) {
			while (n % i == 0) {
				list[index++] = i;
				n /= i;
			}
		}
		return list;

	}

	/**
	 * Reorders <em>a</em> such that all odd values appear before any even values.
	 * The relative orders of the odd numbers to the rest of the odds and of the
	 * even numbers to the rest of the evens does not change.
	 *
	 * <p>
	 * For instance, given <em>a</em> = [ 1, 2, 3, 4, 5, 6, 7 ], return [1, 3, 5, 7,
	 * 2, 4, 6 ].
	 *
	 * @param a An array of integers
	 */
	public static void oddsToFront(int[] a) {
		int[] copy = new int[a.length];
		for (int i = 0; i < a.length; i++) {
			copy[i] = a[i];
		}
		int lIndex = 0, rIndex = a.length - 1;
		for (int i = 0; i < copy.length; i++) {
			if (copy[i] % 2 == 1) {
				a[lIndex++] = copy[i];
			}
		}
		for (int i = copy.length - 1; i >= 0; i--) {
			if (copy[i] % 2 == 0) {
				a[rIndex--] = copy[i];
			}
		}
		System.out.println(Arrays.toString(a));
	}

	/**
	 * Returns a new array containing all of the values from <em>a</em> and
	 * <em>b</em> interleaved (i.e., <em>a[0], b[0], a[1], b[2], ..., a[n - 1], b[n
	 * - 1]</em> where <em>n</em> is the length of the shortest of the two input
	 * arrays) followed by the remaining, non-interleaved values from the longer (if
	 * either) input array.
	 *
	 * <p>
	 * For instance, given <em>a</em> = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] and
	 * <em>b</em> = [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 21, 22, 23],
	 * <em>interleave(a, b)</em> returns [1, 20, 2, 19, 3, 18, 4, 17, 5, 16, 6, 15,
	 * 7, 14, 8, 13, 9, 12, 10, 11, 21, 22, 23].
	 *
	 * @return The interleaved output
	 * @param a An array of integers
	 * @param b An array of integers
	 */
	public static int[] interleave(int[] a, int[] b) {
		int[] result = new int[a.length + b.length];
		int index = 0;
		for (int i = 0; i < a.length || i < b.length; i++) {
			if (i < a.length) {
				result[index++] = a[i];
			}
			if (i < b.length) {
				result[index++] = b[i];
			}
		}
		return result;
	}

	/**
	 * Shuffles the contents of <em>a</em> like, e.g., a deck of cards. Shuffling is
	 * achieved by the following method: Iterating from index 0 through index
	 * <em>length - 1</em> over the input array, swap the value in that index with
	 * the value at the index given by the next random integer modulo
	 * <em>a.length</em>.
	 *
	 * <p>
	 * For instance, with <em>a</em> = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
	 * <em>shuffle(new Random(1995), a)</em> changes <em>a</em> to [3, 6, 1, 10, 5,
	 * 9, 2, 4, 7, 8].
	 *
	 * @param r An instance of <em>Random</em>
	 * @param a An array of integers
	 */
	public static void shuffle(Random r, int[] a) {
		int i;
		int array_length = a.length;
		int random_integer;
		int temp;
		for (i = 0; i < array_length; i++) {
			
			random_integer = r.nextInt(100) % array_length;
			temp = a[i];
			a[i] = a[random_integer];
			a[random_integer] = temp;
		}

		System.out.println(Arrays.toString(a));
	}

	/**
	 * Runs the <a href="https://en.wikipedia.org/wiki/Langton%27s_ant">Langton's
	 * Ant</a> cellular automaton on the input matrix <em>m</em> until the ant steps
	 * off the matrix or until the simulation loop completes <em>maxSteps</em>
	 * iterations. For a description of the automaton, follow the embedded Wikipedia
	 * link above and read the section entitled "Rules". In this simulation, the
	 * value of false denotes a black square, and true denotes a white square. UP is
	 * the negative vertical direction, and LEFT is the negative horizontal
	 * direction. The simulation runs in-place on <em>m</em>.
	 *
	 * <p>
	 * For instance, given the call <em>langtonsAnt(m, 1, 1, Direction.LEFT,
	 * 100)</em> where <em>m</em> is a 3x3 matrix with all values false, the
	 * algorithm will proceed through each of the following internal states before
	 * returning with <em>m</em> referencing the final state:
	 *
	 * <p>
	 * [false, false, false] <br>
	 * [false, true, false] <br>
	 * [false, false, false]
	 * <p>
	 * [false, false, false] <br>
	 * [false, true, false] <br>
	 * [false, true, false]
	 * <p>
	 * [false, false, false] <br>
	 * [false, true, false] <br>
	 * [false, true, true]
	 * <p>
	 * [false, false, false] <br>
	 * [false, true, true] <br>
	 * [false, true, true]
	 * <p>
	 * [false, false, false] <br>
	 * [false, false, true] <br>
	 * [false, true, true]
	 * <p>
	 * [false, true, false] <br>
	 * [false, false, true] <br>
	 * [false, true, true]
	 * <p>
	 * [true, true, false] <br>
	 * [false, false, true] <br>
	 * [false, true, true]
	 * <p>
	 * [true, true, false] <br>
	 * [true, false, true] <br>
	 * [false, true, true]
	 * <p>
	 * [true, true, false] <br>
	 * [true, true, true] <br>
	 * [false, true, true]
	 * <p>
	 * [true, false, false] <br>
	 * [true, true, true] <br>
	 * [false, true, true]
	 * <p>
	 * [true, false, true] <br>
	 * [true, true, true] <br>
	 * [false, true, true]
	 *
	 * <p>
	 * To be clear: your submitted code should not return or print all of these
	 * steps (though that may be useful for debugging)! You should only return the
	 * final matrix given above.
	 *
	 * <p>
	 * And similarly, <em>langtonsAnt(m, 1, 1, Direction.LEFT, 2)</em> should return
	 * the second above matrix.
	 *
	 * @param m        A two-dimensional array of boolean
	 * @param c        The ant's starting column
	 * @param r        The ant's starting row
	 * @param d        The ant's starting direction
	 * @param maxSteps The maximum number of iterations of the simulation
	 */
	public static void langtonsAnt(boolean[][] m, int c, int r, Direction d, int maxSteps) {
		if (maxSteps <= 0 || r >= m.length || r < 0 || c >= m[0].length || c < 0)

			return;

		S2020Mini2.Direction dir = null;


		if (!m[r][c]) {

			if (d == S2020Mini2.Direction.LEFT) {

				m[r][c] = !m[r][c];

				r++;

				dir = S2020Mini2.Direction.UP;

			}

			if (d == S2020Mini2.Direction.UP) {

				m[r][c] = !m[r][c];

				c++;

				dir = S2020Mini2.Direction.RIGHT;

			}

			if (d == S2020Mini2.Direction.RIGHT) {

				m[r][c] = !m[r][c];

				r--;

				dir = S2020Mini2.Direction.DOWN;

			}

			if (d == S2020Mini2.Direction.DOWN) {

				m[r][c] = !m[r][c];

				c--;
				;

				dir = S2020Mini2.Direction.LEFT;

			}

		}



		else {

			if (d == S2020Mini2.Direction.LEFT) {

				m[r][c] = !m[r][c];

				r--;

				dir = S2020Mini2.Direction.DOWN;

			}

			if (d == S2020Mini2.Direction.UP) {

				m[r][c] = !m[r][c];

				c--;

				dir = S2020Mini2.Direction.LEFT;

			}

			if (d == S2020Mini2.Direction.RIGHT) {

				m[r][c] = !m[r][c];

				r++;

				dir = S2020Mini2.Direction.UP;

			}

			if (d == S2020Mini2.Direction.DOWN) {

				m[r][c] = !m[r][c];

				c++;

				dir = S2020Mini2.Direction.RIGHT;

			}

		}


		langtonsAnt(m, c, r, dir, maxSteps - 1);

	}
	
	public static void main(String[] args) {
		//
		System.out.println((Arrays.toString(binomialCoefficients(7))));
		//
		System.out.println((Arrays.toString(factorization(413423478))));
		//
		int[] z = { 1, 2, 3, 4, 5, 6, 7 };
		oddsToFront(z);
		//
		int [] a = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		int [] b = {20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 21, 22, 23};
		System.out.println(Arrays.toString(interleave(a,b)));
		//
		shuffle(new Random(1995), a);
		System.out.println("[3, 6, 1, 10, 5, 9, 2, 4, 7, 8]");
		//
		boolean m[][] = { { false, false, false }, { false, false, false }, { false, false, false } };
		langtonsAnt(m, 1, 1, S2020Mini2.Direction.LEFT, 100);
		for (int i = 0; i < 3; i++) {
			System.out.print("[");
			for (int j = 0; j < 3; j++) {
				System.out.print(" " + m[i][j]);
				if (j < 3 - 1)
					System.out.print(",");
			}
			System.out.print(" ]\n");
		}
	}

}

