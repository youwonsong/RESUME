package hw2;

import java.util.Random;
import hw2.Direction.*;
import hw2.Status;

public class CaveExplorer {
	public static final int MAX_ENERGY = 100;
	private int mClock ;
	private int mEnergy;
	private int mFoodItem;
	private int mMatch;
	private boolean mHasJacket;
	private boolean mHasKey;
	private Map gameMap;
	private Location locationOfP;
	private boolean mHasWon;
	private boolean mIsAlive;
	
	public CaveExplorer(Map map, int clock, int energy, int foodItems, int matches, Location initial) {
//		String mapString = map.toString();
//		String[] mapArray = mapString.split("\n");
//		gameMap = new Map(mapArray);
		gameMap = map;
		mClock = clock;
		mEnergy = energy;
		mFoodItem = foodItems;
		mMatch = matches;
		locationOfP = initial;
				
//		if(gameMap.getCellStatus(initial) == Status.EXIT) {
//			mHasWon = false;
//		}
//		else {
//			//gameMap.mark(initial, Status.PlAYER);	
//		}
	}
	
	public CaveExplorer(Map map, Location initial) {
//		String mapString = map.toString();
//		String[] mapArray = mapString.split("\n");
//		gameMap = new Map(mapArray);
		gameMap = map;
		locationOfP = initial;
		mClock = 100;
		mEnergy = MAX_ENERGY;
		mFoodItem = 1;
		mMatch = 10;
//		if(gameMap.getCellStatus(initial) == Status.EXIT) {
//			mHasWon = true;
//		}
//		else {
//			gameMap.mark(initial, Status.PlAYER);	
//		}
	}
	
	public CaveExplorer(Map map, Random generator) {
//		String mapString = map.toString();
//		String[] mapArray = mapString.split("\n");
//		gameMap = new Map(mapArray);
		gameMap = map;
		mClock =100;
		mMatch = 10;
		mFoodItem =1;
		mEnergy = MAX_ENERGY;
		Location loc = map.getRandomOpenLocation(generator);
		locationOfP = new Location(loc);
		if(gameMap.getCellStatus(loc) == Status.EXIT) {
			mHasWon = true;
		}
//		else {
//			gameMap.mark(loc, Status.PlAYER);	
//		}
		
	}
	
	public String checkResource() {
		mEnergy = mEnergy - 1;
		mClock = mClock - 1;
		return ("FoodItems : " + mFoodItem + "Clock :" + mClock + "Matches :" + mMatch + "Energy :" + mEnergy);
	}
	
	public void eat() {
		if (mFoodItem > 0) {
			mEnergy = mEnergy + 10;
			if (mEnergy > MAX_ENERGY) {
				mEnergy = MAX_ENERGY;
			}
			mFoodItem = mFoodItem - 1;
		}
		mClock = mClock - 1;
	}
	
	public int getClock() {
		return mClock;
	}
	
	public int getEnergy() {
		return mEnergy;
	}
	
	public int getFoodItems() {
		return mFoodItem;
	}
	
	public Location getLocation() {
		return locationOfP;
	}
	
	public Map getMap() {
		return gameMap;
	}
	
	public int getMatches() {
		return mMatch;
	}
	
	public boolean hasJacket() {
		return mHasJacket;
	}
	
	public boolean hasKey() {
		return mHasKey;
	}
	
	public boolean hasWon() {
		return mHasWon;
	}
	
	public boolean isAlive() {
		if (mClock == 0 || mEnergy == 0) {
			return false;
		}
		return true;
	}
	public boolean jump(Direction d) {
		return false;
	}
	
	public String look(Direction d) {
		
		int row = 0;
		int col = 0;
		String ans;
		if (d == Direction.NORTH) {
			row = row - 1;
		} else if (d == Direction.SOUTH) {
			row = row + 1;
		} else if (d == Direction.WEST) {
			col = col - 1;
		} else if (d == Direction.EAST) {
			col = col + 1;
		} 
		mMatch = mMatch - 1;
		mEnergy = mEnergy - 1;
		mClock = mClock - 1;
		if(mMatch <0) {
			mMatch = 0;
			ans = "DARKNESS";
		}else {
			Location loc = new Location(locationOfP.getRow() + row,locationOfP.getCol() + col);
			Status s = gameMap.getCellStatus(loc);
			ans = s.toString();
		}
			return ans;
	}
	
	public boolean move(Direction d) {
		int row = 0;
		int col = 0;
		String ans;
		if (d == Direction.NORTH) {
			row = row - 1;
		} else if (d == Direction.SOUTH) {
			row = row + 1;
		} else if (d == Direction.WEST) {
			col = col - 1;
		} else if (d == Direction.EAST) {
			col = col + 1;
		} 
		
		mEnergy = mEnergy - 1;
		mClock = mClock - 1;
		locationOfP.translate(row, col); //Location loc = new Location(locationOfP.getRow() + row,locationOfP.getCol() + col);
		Status s = gameMap.getCellStatus(locationOfP);
		if(s==Status.WALL) {
			return false;
		}else if(s==Status.DOOR && hasKey() == false) {
			return false;
		}else if(s==Status.WATER) {
			if(hasJacket() == true) {
				mFoodItem = getFoodItems()/2;
				mMatch = getMatches()/2;	
				//gameMap.mark(locationOfP, Status.MARK);
				if(s==Status.OPEN||s==Status.MARK) {
					gameMap.mark(locationOfP, Status.PlAYER);
				
				}
				return true;
			}else {
				mEnergy = 0;
				mIsAlive = false;
				return false;
			}	
		}else if(s==Status.PIT) {
			mEnergy = 0;
			mIsAlive = false;
		}else {
			//gameMap.mark(locationOfP, Status.MARK);
			if(s==Status.OPEN||s==Status.MARK) {
				gameMap.mark(locationOfP, Status.PlAYER);
			}
			return true;
		}
		return false;
	}
	
	public void pickUp() {
//		System.out.println("dkdkdkdkd\n" + gameMap.toString());
//		System.out.println(locationOfP.toString());
		Status s = gameMap.getCellStatus(locationOfP);
		if (s == Status.JACKET) {
			mHasJacket = true;
			gameMap.mark(locationOfP, Status.PlAYER);
		} else if (s == Status.FOOD) {
			mFoodItem = mFoodItem + 1;
			gameMap.mark(locationOfP, Status.PlAYER);
		} else if (s == Status.KEY) {
			mHasKey = true;
			gameMap.mark(locationOfP, Status.PlAYER);
		} else if (s == Status.MATCH) {
			mMatch = mMatch + 20;
			gameMap.mark(locationOfP, Status.PlAYER);
		}
	}
	
	public void rest() {
		mEnergy = mEnergy + 10;
		mClock = mClock - 10;
		if (mEnergy + 10 > MAX_ENERGY) {
			mEnergy = 100;
		}

	}
}
