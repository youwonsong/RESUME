package miniassignment1;

import java.util.Random;

public class S2020Mini1 {
	public static double squareRoot(double d) {
		double guess = d / 2;
		double nextGuess = guess;
		do {
			guess = nextGuess;
			nextGuess = (guess + d / guess) / 2; // Use formula which is in Javadoc
		} while (guess != nextGuess);
		return guess;
	}

	public static int findSmallest(String s) {
		int smallest = 0; // required to know smallestIndex value
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(smallest) > s.charAt(i)) { // find smallest
				smallest = i;
			}
		}
		return smallest;
	}

	public static int sequenceOfLength(Random r, int limit, int length) {
		int countTotal = 0; // set countTotal as Integer
		int countSequence = 0; // set countSequence as Integer
		int preRand = r.nextInt(limit); // random
		countTotal++; // + 1 cuz because of line no.29
		countSequence++; // same as line no 30
		int rand;
		while (countSequence != length) {
			rand = r.nextInt(limit); // do while loop
			countTotal++;
			if (rand - preRand == 1) {
				countSequence++;
			} else {
				countSequence = 1;
			}
			preRand = rand;
		}
		return countTotal;
	}

	public static int nextIndexOf(String s, String sub, int start) {
		for (int i = start + 1; i < s.length(); i++) { // for loop
			if (i + sub.length() > s.length()) {
				return -1;
			}
			String substr = s.substring(i, i + sub.length());
			if (substr.equals(sub)) {
				return i;
			}
		}
		return -1;
	}

	public static int countDifferences(String s, String t) {
		int min;
		if (s.length() >= t.length()) { // compare two string's length and find small one
			min = t.length();
		} else {
			min = s.length();
		}
		int diff = 0;
		for (int i = 0; i < min; i++) {
			if (t.charAt(i) != s.charAt(i)) { // diff++ if it there's difference
				diff++;
			}
		}
		if (s.length() >= t.length()) {
			diff = diff + (s.length() - t.length());
		} else {
			diff = diff + (t.length() - s.length());

		}
		return diff;
	}

	public static boolean isGeometric(String seq) {
		int divide = Integer.parseInt(seq.substring(2, 3)) / Integer.parseInt(seq.substring(0, 1));// Find multiplied
																									// value.
		String[] str = seq.split(","); // split it by , to know the Number value in str.

		for (int i = 0; i < str.length - 1; i++) // use loop if it is correct.
		{
			int a = Integer.parseInt(str[i]);
			int b = Integer.parseInt(str[i + 1]);
			if (a * divide != b) // we can know answer by multiplying divided value.
				return false;
		}
		return true;
	}

	public static String removeSingles(String s) {
		String letter = ""; // make string for remained letters
		for (int i = 0; i < s.length() - 1; i++) { // for loop to removeSingles
			if (s.charAt(i) == s.charAt(i + 1)) {
				letter = letter + s.substring(i, i + 2);
			} else if (s.charAt(i) != s.charAt(i + 1)) {
				letter = letter + "";
			}
		}
		return letter;
	}

	public static void main(String[] args) {
		// squareRoot
		System.out.println("Square Root of 2: " + squareRoot(4));

		// findSmallest
		System.out.println(findSmallest("Apple"));

		// sequenceOfLength
		System.out.println(sequenceOfLength(new Random(1984), 10, 9));
		System.out.println(sequenceOfLength(new Random(1984), 2, 2));

		// nextIndexOf
		String a = "abcdefg";
		String b = "gfe";
		String c = "defg";
		System.out.println(nextIndexOf(a, b, 1));
		System.out.println(nextIndexOf(a, c, 1));

		// countDifferences
		System.out.println(countDifferences("foo", "Foobar"));

		// isGeometric
		System.out.println(isGeometric("1,2,4,8,16,30"));
		System.out.println(isGeometric("1,2,4,8,16,32"));

		// removeSingles
		System.out.println(removeSingles("foo"));
		System.out.println(removeSingles("Mississippi"));
	}
}
