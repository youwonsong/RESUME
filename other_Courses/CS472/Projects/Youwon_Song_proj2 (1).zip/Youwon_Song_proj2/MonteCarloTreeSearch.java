package edu.iastate.cs472.proj2;

/**
 * 
 * @author Youwon Song
 *
 */

import java.util.Random;

/**
 * This class implements the Monte Carlo tree search method to find the best
 * move at the current state.
 */
public class MonteCarloTreeSearch extends AdversarialSearch {

    //Num of MCTS iterations for a move
    private static final int ITERATIONS = 500;

    //Maximum playout length in piles, prevent long rollouts
    private static final int MAX_PLAYOUT_LENGTH = 200;

    private final Random rng = new Random();

    //Player color for this search agent
    private int agentColor = CheckersData.BLACK;


	/**
     * The input parameter legalMoves contains all the possible moves.
     * It contains four integers:  fromRow, fromCol, toRow, toCol
     * which represents a move from (fromRow, fromCol) to (toRow, toCol).
     * It also provides a utility method `isJump` to see whether this
     * move is a jump or a simple move.
     *
     * Each legalMove in the input now contains a single move
     * or a sequence of jumps: (rows[0], cols[0]) -> (rows[1], cols[1]) ->
     * (rows[2], cols[2]).
     *
     * @param legalMoves All the legal moves for the agent at current step.
     */
    public CheckersMove makeMove(CheckersMove[] legalMoves) {

        if (legalMoves == null || legalMoves.length == 0) {
            return null;
        }
        // The checker board state can be obtained from this.board,
        // which is an 2D array of the following integers defined below:
    	// 
        // 0 - empty square,
        // 1 - red man
        // 2 - red king
        // 3 - black man
        // 4 - black king

        // Infer agent color from the first legal move.
        int fRow = legalMoves[0].rows.get(0);
        int fCol = legalMoves[0].cols.get(0);
        int p   = board.pieceAt(fRow, fCol);
        agentColor = (p == CheckersData.RED || p == CheckersData.RED_KING)
                ? CheckersData.RED : CheckersData.BLACK;

        //Generate root node for MCTS
        CheckersData rState = copyBoard(board);
        MCNode<CheckersData> r =
                new MCNode<>(rState, null, null, agentColor, legalMoves);

        //MCTS loop
        for (int i = 0; i < ITERATIONS; i++) {
            //Selection
            MCNode<CheckersData> n = r;
            while (n.untriedMoves.isEmpty() && !n.children.isEmpty()) {
                n = selectChild(n);
            }

            //Expansion
            if (!n.untriedMoves.isEmpty()) {
                int index = rng.nextInt(n.untriedMoves.size());
                CheckersMove m = n.untriedMoves.remove(index);

                CheckersData nState = copyBoard(n.state);
                nState.makeMove(m);
                int nextPlayer = opponentOf(n.playerToMove);
                CheckersMove[] childMoves = nState.getLegalMoves(nextPlayer);

                MCNode<CheckersData> c =
                        new MCNode<>(nState, n, m, nextPlayer, childMoves);
                n.children.add(c);
                n = c;
            }

            //Simulation
            double result = simulate(copyBoard(n.state), n.playerToMove);

            //Back-propagation
            while (n != null) {
                n.visits++;
                n.wins += result;
                n = n.parent;
            }
        }

        //Choose the child of the root with the largest visit count.
        MCNode<CheckersData> bChild = null;
        int bVisits = -1;
        for (MCNode<CheckersData> c : r.children) {
            if (c.visits > bVisits) {
                bVisits = c.visits;
                bChild = c;
            }
        }

        if (bChild == null) {
            // Fallback: select a random legal move.
            return legalMoves[rng.nextInt(legalMoves.length)];
        }

        // TODO

        // Return the move for the current state.
        // Here, we simply return the first legal move for demonstration.
        System.out.println("MCTS chosen move with visits " + bChild.visits);
        System.out.println(board);
        System.out.println();

        return bChild.move;
    }


    // TODO
    // 
    // Implement your helper methods here. They include at least the methods for selection,  
    // expansion, simulation, and back-propagation. 
    // 
    // For representation of the search tree, you are suggested (but limited) to use a 
    // child-sibling tree already implemented in the two classes CSTree and CSNode (which  
    // you may feel free to modify).  If you decide not to use the child-sibling tree, simply 
    // remove these two classes. 
    //

    private MCNode<CheckersData> selectChild(MCNode<CheckersData> node) {
        MCNode<CheckersData> selected = null;
        double bValue = Double.NEGATIVE_INFINITY;

        for (MCNode<CheckersData> c : node.children) {
            if (c.visits == 0) {
                // Make sure that every child is visited at least once.
                return c;
            }
            double exploitation = c.wins / c.visits;
            double exploration = Math.sqrt(2.0 * Math.log(node.visits) / c.visits);
            double ucb1 = exploitation + exploration;

            if (ucb1 > bValue) {
                bValue = ucb1;
                selected = c;
            }
        }
        return selected;
    }

    private double simulate(CheckersData state, int playerToMove) {
        int cPlayer = playerToMove;
        for (int ply = 0; ply < MAX_PLAYOUT_LENGTH; ply++) {
            CheckersMove[] move = state.getLegalMoves(cPlayer);

            if (move == null || move.length == 0) {
                // Current player has no legal move and loses.
                if (cPlayer == agentColor) {
                    return 0.0; // agent loses
                } else {
                    return 1.0; // opponent loses -> agent wins
                }
            }

            CheckersMove m = move[rng.nextInt(move.length)];
            state.makeMove(m);
            cPlayer = opponentOf(cPlayer);
        }

        // Depth limit reached, draw.
        return 0.5;
    }

    //copy board
    private CheckersData copyBoard(CheckersData src) {
        CheckersData cd = new CheckersData();
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                cd.board[i][j] = src.board[i][j];
            }
        }
        return cd;
    }

    //get opponent color
    private int opponentOf(int player) {
        return (player == CheckersData.RED) ? CheckersData.BLACK : CheckersData.RED;
    }
}
