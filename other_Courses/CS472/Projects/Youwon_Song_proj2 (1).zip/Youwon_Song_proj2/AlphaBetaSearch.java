package edu.iastate.cs472.proj2;

/**
 * 
 * @author Youwon Song
 *
 */


import java.util.Random;

/**
 * This class implements the Alpha-Beta pruning algorithm to find the best 
 * move at current state.
*/
public class AlphaBetaSearch extends AdversarialSearch {
    //Maximum search depth
    private static final int MAX_DEPTH = 6;
    //Utility value
    private static final int WIN_SCORE  = 10000;
    private static final int LOSS_SCORE = -WIN_SCORE;

    //Color of agent
    private int agentColor = CheckersData.BLACK;
    private final Random rng = new Random();
    /**
     * The input parameter legalMoves contains all the possible moves.
     * It contains four integers:  fromRow, fromCol, toRow, toCol
     * which represents a move from (fromRow, fromCol) to (toRow, toCol).
     * It also provides a utility method `isJump` to see whether this
     * move is a jump or a simple move.
     * 
     * Each legalMove in the input now contains a single move
     * or a sequence of jumps: (rows[0], cols[0]) -> (rows[1], cols[1]) ->
     * (rows[2], cols[2]).
     *
     * @param legalMoves All the legal moves for the agent at current step.
     */

    public CheckersMove makeMove(CheckersMove[] legalMoves) {
        if(legalMoves == null || legalMoves.length == 0) {
            return null;
        }
        //Infer the agent's color from its first legal move
        int fRow = legalMoves[0].rows.get(0);
        int fCol = legalMoves[0].cols.get(0);
        int p   = board.pieceAt(fRow, fCol);
        agentColor = (p == CheckersData.RED || p == CheckersData.RED_KING)
                ? CheckersData.RED : CheckersData.BLACK;

        int opponent = opponentOf(agentColor);

        int bScore = Integer.MIN_VALUE;
        CheckersMove bMove = legalMoves[0];

        //Use alpha-beta search to evaluate each candidate root move
        for (CheckersMove move : legalMoves) {
            CheckersData nextState = copyBoard(board);
            nextState.makeMove(move);

            int s = alphaBeta(nextState, opponent, 1,
                    Integer.MIN_VALUE, Integer.MAX_VALUE);
            //Use slight randomness in tie-breaking to prevent deterministic play
            if (s > bScore ||
                    (s == bScore && rng.nextBoolean())) {
                bScore = s;
                bMove = move;
            }
        }
        // The checker board state can be obtained from this.board,
        // which is a int 2D array. The numbers in the `board` are
        // defined as
        // 0 - empty square,
        // 1 - red man
        // 2 - red king
        // 3 - black man
        // 4 - black king
        System.out.println("AlphaBeta chosen move with score " + bScore);
        System.out.println(board);
        System.out.println();

        // TODO 
        
        // Return the move for the current state.
        // Here, we simply return the first legal move for demonstration.
        return bMove;
    }
    
    // TODO
    // Implement your helper methods here.
    private int alphaBeta(CheckersData state, int player, int depth, int alpha, int beta) {
        CheckersMove[] moves = state.getLegalMoves(player);

        // Terminal // cutoff test.
        if (moves == null || moves.length == 0 || depth >= MAX_DEPTH) {
            return evaluate(state);
        }

        if (player == agentColor) {
            // Maximize node -> turn for agent
            int v = Integer.MIN_VALUE;
            for (CheckersMove m : moves) {
                CheckersData c = copyBoard(state);
                c.makeMove(m);
                v = Math.max(v, alphaBeta(c, opponentOf(player),
                        depth + 1, alpha, beta));
                alpha = Math.max(alpha, v);
                if (alpha >= beta) {
                    // beta–cutoff when opponent have better way
                    break;
                }
            }
            return v;
        } else {
            // Minimize node -> turn for opponent.
            int v = Integer.MAX_VALUE;
            for (CheckersMove m : moves) {
                CheckersData c = copyBoard(state);
                c.makeMove(m);
                v = Math.min(v, alphaBeta(c, opponentOf(player),
                        depth + 1, alpha, beta));
                beta = Math.min(beta, v);
                if (alpha >= beta) {
                    break; // alpha–cutoff when agent have better way
                }
            }
            return v;
        }
    }
    //Heuristic evaluation function
    private int evaluate(CheckersData state) {
        int agentMen = 0, agentKings = 0;
        int oppMen   = 0, oppKings   = 0;

        //Count pieces and kings for agent and opponent
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                int p = state.board[i][j];
                if (p == CheckersData.EMPTY) {
                    continue;
                }
                boolean isAgent =
                        (agentColor == CheckersData.RED  &&
                                (p == CheckersData.RED || p == CheckersData.RED_KING))
                                || (agentColor == CheckersData.BLACK &&
                                (p == CheckersData.BLACK || p == CheckersData.BLACK_KING));

                boolean isKing = (p == CheckersData.RED_KING || p == CheckersData.BLACK_KING);

                if (isAgent) {
                    if (isKing) {
                        agentKings++;
                    } else {
                        agentMen++;
                    }
                } else {
                    if (isKing) {
                        oppKings++;
                    } else {
                        oppMen++;
                    }
                }
            }
        }
        //men count as 1, king as 2
        int material = (agentMen + 2 * agentKings) - (oppMen + 2 * oppKings);

        // Terminal check using legal moves.
        CheckersMove[] aMoves = state.getLegalMoves(agentColor);
        CheckersMove[] oMoves   = state.getLegalMoves(opponentOf(agentColor));

        if ((aMoves == null || aMoves.length == 0) &&
                (oMoves == null   || oMoves.length   == 0)) {
            return 0;
        } else if (aMoves == null || aMoves.length == 0) {
            return LOSS_SCORE;
        } else if (oMoves == null || oMoves.length == 0) {
            return WIN_SCORE;
        }

        //Mobility m -> difference in the num of legal moves
        int m = 0;

        if (aMoves != null) {
            m += aMoves.length;
        }
        if (oMoves != null) {
            m -= oMoves.length;
        }

        //material -> dominant term, mobility m-> smaller correction
        return material * 10 + m;
    }

    // Generate a copy of CheckerData cd
    private CheckersData copyBoard(CheckersData src) {
        CheckersData cd = new CheckersData();
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                cd.board[r][c] = src.board[r][c];
            }
        }
        return cd;
    }
    //Get opponent color for player
    private int opponentOf(int player) {
        return (player == CheckersData.RED) ? CheckersData.BLACK : CheckersData.RED;
    }
}
