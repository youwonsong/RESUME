package edu.iastate.cs472.proj2;

import java.util.ArrayList;

/**
 * Node type for the Monte Carlo search tree.
 */
public class MCNode<E>
{
  // TODO  
    //Game state represented by this node
    E state;

    //Parent node in the search tree
    MCNode<E> parent;

    //Children of node
    ArrayList<MCNode<E>> children = new ArrayList<>();

    //Legal moves from this node that have not tried yet
    ArrayList<CheckersMove> untriedMoves = new ArrayList<>();

    CheckersMove move;

    int playerToMove;

    //num of visits
    int visits;

    double wins;

    MCNode(E s,
           MCNode<E> p,
           CheckersMove move,
           int playerToMove,
           CheckersMove[] legalMoves)
    {
        this.state = s;
        this.parent = p;
        this.move = move;
        this.playerToMove = playerToMove;
        this.visits = 0;
        this.wins = 0.0;

        //Initialize untriedMoves with copies of all legal moves
        if (legalMoves != null) {
            for (CheckersMove m : legalMoves) {
                this.untriedMoves.add(m.clone());
            }
        }
    }
}

