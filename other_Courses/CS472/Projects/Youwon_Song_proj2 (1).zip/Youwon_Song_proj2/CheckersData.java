package edu.iastate.cs472.proj2;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * An object of this class holds data about a game of checkers.
 * It knows what kind of piece is on each square of the checkerboard.
 * Note that RED moves "up" the board (i.e. row number decreases)
 * while BLACK moves "down" the board (i.e. row number increases).
 * Methods are provided to return lists of available legal moves.
 */
public class CheckersData {

  /*  The following constants represent the possible contents of a square
      on the board.  The constants RED and BLACK also represent players
      in the game. */

    static final int
            EMPTY = 0,
            RED = 1,
            RED_KING = 2,
            BLACK = 3,
            BLACK_KING = 4;


    int[][] board;  // board[r][c] is the contents of row r, column c.


    CheckersData() {
        board = new int[8][8];
        setUpGame();
    }

    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_YELLOW = "\u001B[33m";

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < board.length; i++) {
            int[] row = board[i];
            sb.append(8 - i).append(" ");
            for (int n : row) {
                if (n == 0) {
                    sb.append(" ");
                } else if (n == 1) {
                    sb.append(ANSI_RED + "R" + ANSI_RESET);
                } else if (n == 2) {
                    sb.append(ANSI_RED + "K" + ANSI_RESET);
                } else if (n == 3) {
                    sb.append(ANSI_YELLOW + "B" + ANSI_RESET);
                } else if (n == 4) {
                    sb.append(ANSI_YELLOW + "K" + ANSI_RESET);
                }
                sb.append(" ");
            }
            sb.append(System.lineSeparator());
        }
        sb.append("  a b c d e f g h");

        return sb.toString();
    }

    /**
     * Set up the board with checkers in position for the beginning
     * of a game.  Note that checkers can only be found in squares
     * that satisfy  row % 2 == col % 2.  At the start of the game,
     * all such squares in the first three rows contain black squares
     * and all such squares in the last three rows contain red squares.
     */
    void setUpGame() {
        // TODO
    	// 
    	// Set up the board with pieces BLACK, RED, and EMPTY
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if ((i % 2) == (j % 2)) {
                    // Dark square that is playable
                    if (i < 3) {
                        board[i][j] = BLACK;
                    } else if (i > 4) {
                        board[i][j] = RED;
                    } else {
                        board[i][j] = EMPTY;
                    }
                } else {
                    // Light square that is unplayable
                    board[i][j] = EMPTY;
                }
            }
        }
    }


    /**
     * Return the contents of the square in the specified row and column.
     */
    int pieceAt(int row, int col) {
        return board[row][col];
    }


    /**
     * Make the specified move.  It is assumed that move
     * is non-null and that the move it represents is legal.
     *
     * Make a single move or a sequence of jumps
     * recorded in rows and cols.
     *
     */
    void makeMove(CheckersMove move) {
        int l = move.rows.size();
        for(int i = 0; i < l-1; i++)
            makeMove(move.rows.get(i), move.cols.get(i), move.rows.get(i+1), move.cols.get(i+1));
    }


    /**
     * Make the move from (fromRow,fromCol) to (toRow,toCol).  It is
     * assumed that this move is legal.  If the move is a jump, the
     * jumped piece is removed from the board.  If a piece moves to
     * the last row on the opponent's side of the board, the
     * piece becomes a king.
     *
     * @param fromRow row index of the from square
     * @param fromCol column index of the from square
     * @param toRow   row index of the to square
     * @param toCol   column index of the to square
     */
    void makeMove(int fromRow, int fromCol, int toRow, int toCol) {
        // TODO
    	// 
    	// Update the board for the given move. You need to take care of the following situations:
        // 1. move the piece from (fromRow,fromCol) to (toRow,toCol)
        // 2. if this move is a jump, remove the captured piece
        // 3. if the piece moves into the kings row on the opponent's side of the board, crowned it as a king

        int p = board[fromRow][fromCol];
        board[fromRow][fromCol] = EMPTY;

        // check if this is a jump move or not
        if (Math.abs(fromRow - toRow) == 2 && Math.abs(fromCol - toCol) == 2) {
            int jumpedRow = (fromRow + toRow) / 2;
            int jumpedCol = (fromCol + toCol) / 2;
            board[jumpedRow][jumpedCol] = EMPTY;
        }

        // Move piece
        int nPiece = p;
        // Become king when reaching the last row on opponent's side
        if (p == RED && toRow == 0) {
            nPiece = RED_KING;
        } else if (p == BLACK && toRow == 7) {
            nPiece = BLACK_KING;
        }
        board[toRow][toCol] = nPiece;
    }

    /**
     * Return an array containing all the legal CheckersMoves
     * for the specified player on the current board.  If the player
     * has no legal moves, null is returned.  The value of player
     * should be one of the constants RED or BLACK; if not, null
     * is returned.  If the returned value is non-null, it consists
     * entirely of jump moves or entirely of regular moves, since
     * if the player can jump, only jumps are legal moves.
     *
     * @param player color of the player, RED or BLACK
     */
    CheckersMove[] getLegalMoves(int player) {
        // TODO
        if (player != RED && player != BLACK) {
            return null;
        }

        int playerMan  = (player == RED) ? RED       : BLACK;
        int playerKing = (player == RED) ? RED_KING  : BLACK_KING;

        ArrayList<CheckersMove> moves = new ArrayList<>();

        // Look for possible jump and only jump is possible if jump is possible
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                int p = board[i][j];
                if (p == playerMan || p == playerKing) {
                    CheckersMove[] jumps = getLegalJumpsFrom(player, i, j);
                    if (jumps != null) {
                        moves.addAll(Arrays.asList(jumps));
                    }
                }
            }
        }

        if (!moves.isEmpty()) {
            return moves.toArray(new CheckersMove[moves.size()]);
        }

        // when there is no jump possible, check one step diagonal moves
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                int p = board[i][j];
                if (p != playerMan && p != playerKing) {
                    continue;
                }

                boolean isKing = (p == RED_KING || p == BLACK_KING);

                // Forward direction depends on color of the player.
                int forward = (player == RED) ? -1 : 1;

                // Forward moves (men + kings).
                int newRow = i + forward;
                if (newRow >= 0 && newRow < 8) {
                    if (j - 1 >= 0 && board[newRow][j - 1] == EMPTY) {
                        CheckersMove m = new CheckersMove();
                        m.rows.add(i);
                        m.cols.add(j);
                        m.rows.add(newRow);
                        m.cols.add(j - 1);
                        moves.add(m);
                    }
                    if (j + 1 < 8 && board[newRow][j + 1] == EMPTY) {
                        CheckersMove m = new CheckersMove();
                        m.rows.add(i);
                        m.cols.add(j);
                        m.rows.add(newRow);
                        m.cols.add(j + 1);
                        moves.add(m);
                    }
                }

                // Backward moves for kings only.
                if (isKing) {
                    int backRow = i - forward;
                    if (backRow >= 0 && backRow < 8) {
                        if (j - 1 >= 0 && board[backRow][j - 1] == EMPTY) {
                            CheckersMove m = new CheckersMove();
                            m.rows.add(i);
                            m.cols.add(j);
                            m.rows.add(backRow);
                            m.cols.add(j - 1);
                            moves.add(m);
                        }
                        if (j + 1 < 8 && board[backRow][j + 1] == EMPTY) {
                            CheckersMove m = new CheckersMove();
                            m.rows.add(i);
                            m.cols.add(j);
                            m.rows.add(backRow);
                            m.cols.add(j + 1);
                            moves.add(m);
                        }
                    }
                }
            }
        }

        if (moves.isEmpty()) {
            return null;
        }
        return moves.toArray(new CheckersMove[moves.size()]);
    }


    /**
     * Return a list of the legal jumps that the specified player can
     * make starting from the specified row and column.  If no such
     * jumps are possible, null is returned.  The logic is similar
     * to the logic of the getLegalMoves() method.
     *
     * Note that each CheckerMove may contain multiple jumps.
     * Each move returned in the array represents a sequence of jumps
     * until no further jump is allowed.
     *
     * @param player The player of the current jump, either RED or BLACK.
     * @param row    row index of the start square.
     * @param col    col index of the start square.
     */
    CheckersMove[] getLegalJumpsFrom(int player, int row, int col) {
        // TODO 
        if (player != RED && player != BLACK) {
            return null;
        }

        int p = board[row][col];
        if (p == EMPTY) {
            return null;
        }
        if (player == RED && !(p == RED || p == RED_KING)) {
            return null;
        }
        if (player == BLACK && !(p == BLACK || p == BLACK_KING)) {
            return null;
        }

        ArrayList<CheckersMove> res = new ArrayList<>();
        int[][] boardCopy = copyBoardArray(this.board);

        //Start recursive search for every jump sequences
        findJumpsFrom(res, boardCopy, player, row, col, null);

        if (res.isEmpty()) {
            return null;
        }
        return res.toArray(new CheckersMove[res.size()]);
    }


    private void findJumpsFrom(ArrayList<CheckersMove> result,
                               int[][] state,
                               int player,
                               int row,
                               int col,
                               CheckersMove path) {

        int p = state[row][col];
        boolean isKing = (p == RED_KING || p == BLACK_KING);

        // Determine allowed row directions for jump.
        int[] dir;
        if (isKing) {
            dir = new int[]{-2, 2};
        } else if (p == RED) {
            dir = new int[]{-2};
        } else { // BLACK man
            dir = new int[]{2};
        }

        boolean hasJump = false;

        for (int dr : dir) {
            // can jump both left and right for every vertical direction
            for (int dc : new int[]{-2, 2}) {
                int midRow  = row + dr / 2;
                int midCol  = col + dc / 2;
                int destRow = row + dr;
                int destCol = col + dc;

                //check array bound
                if (destRow < 0 || destRow > 7 || destCol < 0 || destCol > 7) {
                    continue;
                }
                if (midRow < 0 || midRow > 7 || midCol < 0 || midCol > 7) {
                    continue;
                }

                int midPiece  = state[midRow][midCol];
                int destPiece = state[destRow][destCol];

                //Destination needs to be empty, jumped piece needs to belong to opponent
                if (destPiece != EMPTY) {
                    continue;
                }
                if (!isEnemyPiece(player, midPiece)) {
                    continue;
                }

                hasJump = true;

                // Put this jump on a copied board.
                int[][] nState = copyBoardArray(state);
                int mPiece = p;
                nState[row][col] = EMPTY;
                nState[midRow][midCol] = EMPTY;

                // Move to destination and possibly crown.
                if (mPiece == RED && destRow == 0) {
                    mPiece = RED_KING;
                } else if (mPiece == BLACK && destRow == 7) {
                    mPiece = BLACK_KING;
                }
                nState[destRow][destCol] = mPiece;

                // Extend the current path.
                CheckersMove nPath;
                if (path == null) {
                    nPath = new CheckersMove();
                    nPath.rows.add(row);
                    nPath.cols.add(col);
                } else {
                    nPath = path.clone();
                }
                nPath.rows.add(destRow);
                nPath.cols.add(destCol);

                // Continue to search for more jump from new position
                findJumpsFrom(result, nState, player, destRow, destCol, nPath);
            }
        }

        // If no further jumps, the current path is a complete move.
        if (!hasJump && path != null) {
            result.add(path);
        }
    }

    //copy board 8 * 8
    private int[][] copyBoardArray(int[][] src) {
        int[][] dst = new int[8][8];
        for (int r = 0; r < 8; r++) {
            System.arraycopy(src[r], 0, dst[r], 0, 8);
        }
        return dst;
    }

    //check a piece if it belongs to opponent or not
    private boolean isEnemyPiece(int player, int piece) {
        if (piece == EMPTY) {
            return false;
        }
        if (player == RED) {
            return (piece == BLACK || piece == BLACK_KING);
        } else {
            return (piece == RED || piece == RED_KING);
        }
    }
}
