//departments
LOAD CSV WITH headers FROM 'file:///departments.csv' AS line
CREATE (:departments {dcode:toInteger(line.dcode),dname:line.name,phone:toInteger(line.phone),college:line.college});
//degree
LOAD CSV with headers FROM 'file:///degrees.csv' AS line
CREATE (d:degree {dname:line.name,level:line.level})
WITH d , line
MATCH (p:departments {dcode:toInteger(line.dcode)})
CREATE (p)-[:administer]->(d);

//courses
LOAD CSV WITH HEADERS FROM 'file:///courses.csv' AS line
CREATE (c:courses {cnumber:toInteger(line.number),cname:line.name,description:line.description,credithours:toInteger(line.credithours), level:line.level})
WITH c , line
MATCH (p:departments {dcode:toInteger(line.dcode)})
CREATE (p)-[:offer]->(c);

//students
LOAD CSV WITH HEADERS FROM 'file:///students.csv' AS line
CREATE (:students{snum:toInteger(line.snum),ssn:toInteger(line.ssn),name:line.name,gender:line.gender,dob:line.dob,c_addr:line.c_addr,c_phone:line.c_phone,p_addr:line.p_addr,p_phone:toInteger(line.p_phone)});
//register
LOAD CSV WITH HEADERS FROM 'file:///register.csv' AS line
match(s:students {snum:toInteger(line.snum)}),(c:courses {cnumber:toInteger(line.course_number)})
create (s) - [:register {rtime:line.regtime , grade:toInteger(line.grade)}] -> (c);

//major
LOAD CSV WITH HEADERS FROM 'file:///major.csv' AS line
match(s:students {snum:toInteger(line.snum)}), (d:degree {dname:line.name, level:line.level})
create (s) - [:major] -> (d);
//minor
LOAD CSV WITH HEADERS FROM 'file:///minor.csv' AS line
match(s:students {snum:toInteger(line.snum)}), (d:degree {dname:line.name, level:line.level})
create (s) - [:minor] -> (d);