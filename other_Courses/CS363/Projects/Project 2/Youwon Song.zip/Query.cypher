//1)
MATCH(s: students)
where s.name = "Becky"
return s.snum, s.ssn;

//2)
MATCH (s: students) - [:major] -> (d: degree)
where s.ssn = 123097834
return d.dname, d.level;

//3)
MATCH (p: departments)-[:offer]->(c: courses)
where p.dname = "Computer Science"
return c.cname;

//4)
MATCH (p: departments)-[:administer]->(d: degree)
where p.dname = "Computer Science"
return d.dname, d.level;

//5)
MATCH (s:students) - [:minor] -> (d:degree)
return s.name;

//6)
MATCH (s:students) - [:minor] -> (d:degree)
return count(s);

//7)
MATCH (s: students) - [:register] -> (c: courses)
where c.cname = "Algorithm"
return s.name, s.snum;

//8)
MATCH(e:students)
WITH min(date(e.dob)) as min
MATCH(s:students)
where date(s.dob) = min
return s.name, s.snum;

//9)
MATCH(e:students)
WITH max(date(e.dob)) as max
MATCH(s:students)
where date(s.dob) = max
return s.name, s.snum;

//10)
MATCH (s: students)
where s.name contains 'n' OR s.name contains 'N'
return s.name, s.snum, s.ssn;

//11)
MATCH (s: students)
where not(s.name contains 'n') AND not(s.name contains 'N')
return s.name, s.snum, s.ssn;


//12)
MATCH (s: students) - [:register] -> (c: courses)
return c.cnumber, c.cname, count (s);

//13)
MATCH (s: students) - [r:register] -> (c: courses)
where r.rtime = "Fall2020"
return s.name;

//14)
MATCH (p: departments)-[:offer]->(c: courses)
where p.dname = "Computer Science"
return c.cnumber, c.cname;

//15)
MATCH (p: departments)-[:offer]->(c: courses)
where p.dname = "Computer Science" OR p.dname = "Landscape Architect"
return c.cnumber, c.cname;