package edu.iastate.cs228.hw1;

public class Reseller extends TownCell {
	public Reseller(Town p, int r, int c) {
		super(p, r, c);
	}

	@Override
	public State who() {
		return State.RESELLER;
	}

	@Override
	public TownCell next(Town tNew) {
		TownCell cell = null;
		int neighbors[] = new int[NUM_CELL_TYPE];
		census(neighbors);
		if (neighbors[CASUAL] <= 3)
			cell = new Empty(tNew, row, col);
		else if (neighbors[EMPTY] >= 3)
			cell = new Empty(tNew, row, col);
		if (cell == null && neighbors[CASUAL] >= 5)
			cell = new Streamer(tNew, row, col);
		else
			new Reseller(tNew, row, col);

		tNew.grid[row][col] = cell;
		return cell;
	}

}
