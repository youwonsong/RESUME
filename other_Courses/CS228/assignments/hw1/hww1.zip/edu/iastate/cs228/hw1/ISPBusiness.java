package edu.iastate.cs228.hw1;

import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author <<Write your name here>>
 *
 *         The ISPBusiness class performs simulation over a grid plain with
 *         cells occupied by different TownCell types.
 *
 */
public class ISPBusiness {

	/**
	 * Returns a new Town object with updated grid value for next billing cycle.
	 * 
	 * @param tOld: old/current Town object.
	 * @return: New town object.
	 */
	public static Town updatePlain(Town tOld) {
		Town tNew = new Town(tOld.getLength(), tOld.getWidth());
		// TODO: Write your code here.
		return tNew;
	}

	/**
	 * Returns the profit for the current state in the town grid.
	 * @param town
	 * @return
	 */
	public static int getProfit(Town town) {
		//TODO: Write/update your code here.
		int totalProfit = 0;
		Town t = new Town(town.getLength(),town.getWidth());
		TownCell[][] tc = t.grid;
		for(int i = 0; i < town.getLength(); i++) {
			for(int j = 0; j < town.getWidth(); j++) {
				TownCell cell = tc[i][j];
				if(cell.toString() == "C") {
					totalProfit++;
				}
			}	
		}
		

	return totalProfit;

	}

	/**
	 * Main method. Interact with the user and ask if user wants to specify elements
	 * of grid via an input file (option: 1) or wants to generate it randomly
	 * (option: 2).
	 * 
	 * Depending on the user choice, create the Town object using respective
	 * constructor and if user choice is to populate it randomly, then populate the
	 * grid here.
	 * 
	 * Finally: For 12 billing cycle calculate the profit and update town object
	 * (for each cycle). Print the final profit in terms of %. You should only print
	 * the integer part (Just print the integer value. Example if profit is 35.56%,
	 * your output should be just: 35).
	 * 
	 * Note that this method does not throws any exception, thus you need to handle
	 * all the exceptions in it.
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		// TODO: Write your code here.

		Town town = null;
		Scanner console = new Scanner(System.in);
		System.out.println("How to populate grid (type 1 or 2): 1: from a file. 2: randomly with seed");
		int choice = console.nextInt();
		console.nextLine();

		if (choice == 2) {
			System.out.println("Provide rows, cols and seed integer separated by space:");
			String line = console.nextLine();
			String[] array = line.trim().split(" ");
			int row = Integer.parseInt(array[0]);
			int col = Integer.parseInt(array[1]);
			int seed = Integer.parseInt(array[2]);
			town = new Town(row, col);
			town.randomInit(seed);

			System.out.println(town.toString());
		} else if (choice == 1) {
			System.out.println("Please enter file path:");
			// String path = console.nextLine();
			String path = "/Users/Youwon/Downloads/ISP4x4.txt";

			try {
				town = new Town(path);
				System.out.println(town.toString());
			} catch (FileNotFoundException e) {

			}

		}

		for (int i = 0; i < 12; i++) {
			System.out.println("After itr: " + i);
			town.toString();
			// System.out.println("Pfofit: " + town.)

		}

	}
}
