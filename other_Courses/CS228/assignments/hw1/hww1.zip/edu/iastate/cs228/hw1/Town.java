package edu.iastate.cs228.hw1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;

/**
 * @author <<Write your name here>>
 *
 */
public class Town {

	private int length, width; // Row and col (first and second indices)
	public TownCell[][] grid;

	/**
	 * Constructor to be used when user wants to generate grid randomly, with the
	 * given seed. This constructor does not populate each cell of the grid (but
	 * should assign a 2D array to it).
	 * 
	 * @param length
	 * @param width
	 */
	public Town(int length, int width) {
		this.length = length;
		this.width = width;
		grid = new TownCell[length][width];
	}

	/**
	 * Constructor to be used when user wants to populate grid based on a file.
	 * Please see that it simple throws FileNotFoundException exception instead of
	 * catching it. Ensure that you close any resources (like file or scanner) which
	 * is opened in this function.
	 * 
	 * @param inputFileName
	 * @throws FileNotFoundException
	 */
	public Town(String inputFileName) throws FileNotFoundException {
		Scanner scanner = new Scanner(new File(inputFileName));
		// We assume that text file has correct format
		// get length and width and create town cells
		String line = scanner.nextLine();
		String[] array = line.split(" ");
		length = Integer.parseInt(array[0]);
		width = Integer.parseInt(array[1]);
		grid = new TownCell[length][width];

		// fill with actual cell
		int row = 0;
		while (scanner.hasNextLine()) {
			line = scanner.nextLine();

			array = line.trim().split(" ");
			for (int col = 0; col < width; col++) {
				if (array[col].contains("C")) {
					grid[row][col] = new Casual(this, row, col);
				} else if (array[col].contains("S")) {
					grid[row][col] = new Streamer(this, row, col);
				} else if (array[col].contains("R")) {
					grid[row][col] = new Reseller(this, row, col);
				} else if (array[col].contains("O")) {
					grid[row][col] = new Outage(this, row, col);
				} else if (array[col].contains("E")) {
					grid[row][col] = new Empty(this, row, col);
				}
			}
			row++;
		}
		scanner.close();
	}

	/**
	 * Returns width of the grid.
	 * 
	 * @return
	 */
	public int getWidth() {
		return length;
	}

	/**
	 * Returns length of the grid.
	 * 
	 * @return
	 */
	public int getLength() {
		return width;
	}

	/**
	 * Initialize the grid by randomly assigning cell with one of the following
	 * class object: Casual, Empty, Outage, Reseller OR Streamer
	 */
	public void randomInit(int seed) {
		Random rand = new Random(seed);
		for (int row = 0; row < length; row++) {
			for (int col = 0; col < width; col++) {
				int type = rand.nextInt(5);
				if (type == TownCell.CASUAL) {
					grid[row][col] = new Casual(this, row, col);
				} else if (type == TownCell.STREAMER) {
					grid[row][col] = new Streamer(this, row, col);
				} else if (type == TownCell.RESELLER) {
					grid[row][col] = new Reseller(this, row, col);
				} else if (type == TownCell.OUTAGE) {
					grid[row][col] = new Outage(this, row, col);
				} else if (type == TownCell.EMPTY) {
					grid[row][col] = new Empty(this, row, col);
				}
			}
		}
	}

	/**
	 * Output the town grid. For each square, output the first letter of the cell
	 * type. Each letter should be separated either by a single space or a tab. And
	 * each row should be in a new line. There should not be any extra line between
	 * the rows.
	 */
	@Override
	public String toString() {
		String s = "";
		for (int i = 0; i < length; i++) {
			for (int j = 0; j < width; j++) {
				State state = grid[i][j].who();
				if (state == State.CASUAL)
					s += "C ";
				else if (state == State.STREAMER)
					s += "S ";
				else if (state == State.RESELLER)
					s += "R ";
				else if (state == State.EMPTY)
					s += "E ";
				else if (state == State.OUTAGE)
					s += "O ";
			}
			s += System.lineSeparator();
		}
		return s;
	}

}
