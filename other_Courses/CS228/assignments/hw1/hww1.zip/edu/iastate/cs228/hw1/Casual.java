package edu.iastate.cs228.hw1;

public class Casual extends TownCell {
	public Casual(Town p, int r, int c) {
		super(p, r, c);
	}

	@Override
	public State who() {
		return State.CASUAL;
	}

	@Override
	public TownCell next(Town tNew) {
		TownCell cell = null;
		int neighbors[] = new int[NUM_CELL_TYPE];
		census(neighbors);
		if (neighbors[RESELLER] > 0)
			cell = new Outage(tNew, row, col);
		else if (neighbors[STREAMER] > 0)
			cell = new Streamer(tNew, row, col);
		if ((neighbors[EMPTY] + neighbors[OUTAGE]) <= 1)
			cell = new Reseller(tNew, row, col);
		if (cell == null && neighbors[CASUAL] >= 5)
			cell = new Streamer(tNew, row, col);
		if (cell == null)
			cell = new Casual(tNew, row, col);

		tNew.grid[row][col] = cell;
		return cell;
	}

}
