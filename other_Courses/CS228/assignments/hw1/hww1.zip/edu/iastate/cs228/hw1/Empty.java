package edu.iastate.cs228.hw1;

public class Empty extends TownCell {
	public Empty(Town p, int r, int c) {
		super(p, r, c);
	}

	@Override
	public State who() {
		return State.EMPTY;
	}

	@Override
	public TownCell next(Town tNew) {			
		TownCell cell = new Casual(tNew, row, col);
		int neighbors[] = new int[NUM_CELL_TYPE];
		census(neighbors);		
		if((neighbors[EMPTY] + neighbors[OUTAGE]) <= 1)
			cell = new Reseller(tNew, row, col);
		
		tNew.grid[row][col] = cell;
		return cell;
	}

}
