package edu.iastate.cs228.hw2.template;

import java.util.Comparator;

/**
 * An implementation of {@link Sorter} that performs insertion sort to sort the
 * list.
 *
 */
public class InsertionSorter extends Sorter {
	@Override
	public void sort(WordList toSort, Comparator<String> comp) throws NullPointerException {

		for (int i = 1; i < toSort.length(); i++) {
			int k = i;

			while (k > 0 && (comp.compare(toSort.get(k), toSort.get(k - 1)) < 0)) {
				String temp = toSort.get(k);
				toSort.set(k, toSort.get(k - 1));
				toSort.set(k - 1, temp);
				k--;
			}
		}
	}
}