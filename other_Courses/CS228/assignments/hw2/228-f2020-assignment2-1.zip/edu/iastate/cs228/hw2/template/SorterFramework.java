package edu.iastate.cs228.hw2.template;

import java.io.FileNotFoundException;
import java.util.Comparator;

/**
 * An class that compares various methods of sorting.
 * 
 * @author Mike Petersen
 */
public class SorterFramework {
	/**
	 * Loads data necessary to run the sorter statistics output, and runs it. The
	 * only logic within this method should be that necessary to use the given file
	 * names to create the {@link AlphabetComparator}, {@link WordList}, and sorters
	 * to use, and then using them to run the sorter statistics output.
	 * 
	 * @param args an array expected to contain two arguments: - the name of a file
	 *             containing the ordering to use to compare characters - the name
	 *             of a file containing words containing only characters in the
	 *             other file
	 */
	public static void main(String[] args)
			throws NullPointerException, FileNotFoundException, IllegalArgumentException, CloneNotSupportedException {
		// TODO 

		Alphabet a = new Alphabet(args[0]);
		AlphabetComparator comparator = new AlphabetComparator(a); // calls constructor for alphabet comparator
		WordList w;
		Sorter[] s = new Sorter[3]; // set up array with the different sorters
		s[0] = new QuickSorter();
		s[1] = new InsertionSorter();
		s[2] = new MergeSorter();
		w = new WordList(args[1]);
		int tot = 1000000;
		SorterFramework sF = new SorterFramework(s, comparator, w, tot);
		sF.run();
	}

	/**
	 * The comparator to use for sorting.
	 */
	private Comparator<String> comparator;

	/**
	 * The words to sort.
	 */
	private WordList words;

	/**
	 * The array of sorters to use for sorting.
	 */
	private Sorter[] sorters;

	/**
	 * The total amount of words expected to be sorted by each sorter.
	 */
	private int totalToSort;

	/**
	 * Constructs and initializes the SorterFramework.
	 * 
	 * @param sorters     the array of sorters to use for sorting
	 * @param comparator  the comparator to use for sorting
	 * @param words       the words to sort
	 * @param totalToSort the total amount of words expected to be sorted by each
	 *                    sorter
	 * @throws NullPointerException     if any of {@code sorters},
	 *                                  {@code comparator}, {@code words}, or
	 *                                  elements of {@code sorters} are {@code null}
	 * @throws IllegalArgumentException if {@code totalToSort} is negative
	 */
	public SorterFramework(Sorter[] sorters, Comparator<String> comparator, WordList words, int totalToSort)
			throws NullPointerException, IllegalArgumentException {
		// TODO
		this.comparator = comparator;
		this.totalToSort = totalToSort;
		this.sorters = sorters;
		this.words = words;

	}

	/**
	 * Runs all sorters using
	 * {@link Sorter#sortWithStatistics(WordList, Comparator, int)
	 * sortWithStatistics()}, and then outputs the following information for each
	 * sorter: - the name of the sorter - the length of the word list sorted each
	 * time - the total number of words sorted - the total time used to sort words -
	 * the average time to sort the word list - the number of elements sorted per
	 * second - the total number of comparisons performed
	 */
	public void run() throws NullPointerException, IllegalArgumentException, CloneNotSupportedException {
		// TODO
		for (int i = 0; i < sorters.length; i++) {
			sorters[i].sortWithStatistics(words, comparator, totalToSort);
		}
	}

}
