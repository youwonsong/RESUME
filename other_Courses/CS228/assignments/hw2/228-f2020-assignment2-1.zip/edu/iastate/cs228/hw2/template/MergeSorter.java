package edu.iastate.cs228.hw2.template;

import java.util.Comparator;

/**
 * An implementation of {@link Sorter} that performs merge sort to sort the
 * list.
 *
 *
 * didn't get to test any of my sorts and this one in particular may very well
 * be incorrect. Sorry:(
 */
public class MergeSorter extends Sorter {
	@Override
	public void sort(WordList toSort, Comparator<String> comp) throws NullPointerException {

		if (toSort == null || comp == null) {
			throw new NullPointerException();
		}
		mergeSortRec(toSort, comp, 0, toSort.length() - 1);
	}

	private void mergeSortRec(WordList list, Comparator<String> comp, int start, int end) {

		int midPoint = (end - start) / 2;
		int n = midPoint - start + 1;
		int n1 = end - midPoint;
		String[] words = list.getArray();
		String[] left = new String[midPoint - start + 1];
		String[] right = new String[end - midPoint];

		for (int i = 0; i < n; i++) {
			left[i] = words[i + 1];
		}
		for (int i = 0; i < n1; i++) {
			right[i] = words[i + midPoint + 1];
		}

		// start merging

		int index0 = 0;
		int index1 = 0;
		int index2 = start;

		while (index0 < n && index1 < n1) {
			if (comp.compare(left[index0], right[index1]) <= 0) {
				words[index2] = left[index0];
				index1++;
			} else {
				words[index2] = right[index1];
				index1++;
			}
			index2++;
		}

		while (index0 < n) // copies remaining elements of the left array
		{
			words[index2] = left[index0];
			index0++;
			index2++;
		}

		while (index1 < n1) // copies remaining elements of the right array
		{
			words[index2] = right[index1];
			index1++;
			index2++;
		}
	}
}
