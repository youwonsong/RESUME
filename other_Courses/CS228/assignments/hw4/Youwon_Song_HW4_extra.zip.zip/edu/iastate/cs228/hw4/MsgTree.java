package edu.iastate.cs228.hw4;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MsgTree {
	public char payloadChar;
	public MsgTree left;
	public MsgTree right;

	private static int staticCharIdx = 0;

	public MsgTree(String encodingString) {
		if (staticCharIdx >= encodingString.length())
			return;
		char ch = encodingString.charAt(staticCharIdx);
		if (ch == '^') {
			payloadChar = '\0';
			staticCharIdx++;
			left = new MsgTree(encodingString);
			staticCharIdx++;
			right = new MsgTree(encodingString);
		} else {
			payloadChar = ch;
			left = null;
			right = null;
		}

	}

	public MsgTree(char payloadChar) {
		this.payloadChar = payloadChar;
		left = null;
		right = null;
	}

	public static void printCodes(MsgTree root, String code) {
		if (root == null)
			return;
		if (root.left == null && root.right == null) {
			System.out.println(root.payloadChar + "\t\t" + code);
		}
		printCodes(root.left, code + "0");
		printCodes(root.right, code + "1");
	}

	public void decode(MsgTree codes, String msg) {
		MsgTree tree = codes;
		String ans = "";
		int i = 0;
		while (i < msg.length()) {
			char ch = msg.charAt(i);

			if (tree.left == null && tree.right == null) {
				ans += tree.payloadChar;
				tree = codes;
				continue;
			}
			if (ch == '0') {
				tree = tree.left;
			} else {
				tree = tree.right;
			}
			i++;
		}

		if (tree.left == null && tree.right == null) {
			ans += tree.payloadChar;
		}

		System.out.println(ans);
	}

	public static void main(String[] args) throws FileNotFoundException {

		Scanner sc = new Scanner(System.in);

		System.out.println("Please enter file name to decode: ");

		String fileName = sc.nextLine();

		if (fileName == null) {

			throw new FileNotFoundException("There's no file");

		}

		File file = new File(fileName);

		sc.close();

		Scanner sc2 = new Scanner(file);

		int lineCount = 0;

		String l1 = sc2.nextLine();
		String l2 = "";
		String combined = "";

		if (l1.contains("\n")) {
			l2 = sc2.nextLine();
		}
		if (l2.equals("")) {

			combined = l1;
		} else {
			combined = l1 + l2;

		}

		MsgTree tree = new MsgTree(combined);

	}

}