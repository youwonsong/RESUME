//Author : Youwon Song

#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define MAXLINE 128
#define MAXWORKERS 16

static void
strip_newline(char *s)
{
  int i = 0;
  while (s[i]) {
    if (s[i] == '\n') {
      s[i] = '\0';
      return;
    }
    i++;
  }
}

static int
is_space(char c)
{
  return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\v' || c == '\f';
}

static int
starts_with(const char *s, const char *pfx)
{
  int i = 0;
  while (pfx[i]) {
    if (s[i] != pfx[i]) return 0;
    i++;
  }
  return 1;
}

// Parse a positive integer from s.
// Returns 1 -> success, 0 -> failure.
static int
parse_pos_int(const char *s, int *out)
{
  int i = 0;
  while (s[i] && is_space(s[i])) i++;
  if (s[i] < '0' || s[i] > '9') return 0;

  int val = 0;
  while (s[i] >= '0' && s[i] <= '9') {
    val = val * 10 + (s[i] - '0');
    i++;
  }
  // allow trailing spaces only
  while (s[i]) {
    if (!is_space(s[i])) return 0;
    i++;
  }
  if (val <= 0) return 0;
  *out = val;
  return 1;
}

enum mode_kind {
  MODE_ALL = 1,
  MODE_FIRST = 2,
  MODE_SKIP = 3
};

// Parse mode line into (kind, k).
// For MODE_ALL, k is unused.
// Returns 1 -> success, 0 -> malformed.
static int
parse_mode_line(const char *line, enum mode_kind *kind, int *k)
{
  // exact ":all" 
  // trim leading/trailing spaces by checking patterns manually.
  int i = 0;
  while (line[i] && is_space(line[i])) i++;

  if (starts_with(line + i, ":all")) {
    int j = i + 4;
    while (line[j]) {
      if (!is_space(line[j])) return 0;
      j++;
    }
    *kind = MODE_ALL;
    *k = 0;
    return 1;
  }

  if (starts_with(line + i, ":first")) {
    int j = i + 6;
    // need to get at least one space then number
    if (!line[j] || !is_space(line[j])) return 0;
    int val = 0;
    if (!parse_pos_int(line + j, &val)) return 0;
    *kind = MODE_FIRST;
    *k = val;
    return 1;
  }

  if (starts_with(line + i, ":skip")) {
    int j = i + 5;
    if (!line[j] || !is_space(line[j])) return 0;
    int val = 0;
    if (!parse_pos_int(line + j, &val)) return 0;
    *kind = MODE_SKIP;
    *k = val;
    return 1;
  }

  return 0;
}

static void
append_worker_tag(int id, const char *in, char *out, int outsz)
{
  // out = in + " [W<id>]"
  // id assumed < 100 for safety; but MAXWORKERS is small.
  memset(out, 0, outsz);
  int len = strlen(in);
  if (len >= outsz) len = outsz - 1;
  memmove(out, in, len);
  out[len] = '\0';

  char suffix[16];
  memset(suffix, 0, sizeof(suffix));

  // Build " [W<id>]"
  // xv6 doesn't have snprintf; do manual.
  int p = 0;
  suffix[p++] = ' ';
  suffix[p++] = '[';
  suffix[p++] = 'W';

  if (id >= 10) {
    suffix[p++] = '0' + (id / 10);
    suffix[p++] = '0' + (id % 10);
  } else {
    suffix[p++] = '0' + id;
  }

  suffix[p++] = ']';
  suffix[p] = '\0';

  int cur = strlen(out);
  int sfx = strlen(suffix);
  if (cur + sfx >= outsz) {
    // truncate safely
    int room = outsz - 1 - cur;
    if (room > 0) {
      memmove(out + cur, suffix, room);
      out[cur + room] = '\0';
    }
    return;
  }

  strcpy(out + cur, suffix);
}

static void
worker_loop(int id, int read_fd, int write_fd)
{
  char buf[MAXLINE];
  char out[MAXLINE];

  while (1) {
    memset(buf, 0, sizeof(buf));
    int r = read(read_fd, buf, sizeof(buf));
    if (r <= 0) break;

    // termination
    if (strcmp(buf, ":exit") == 0 || strcmp(buf, ":EXIT") == 0) {
      // clean Exit 
      break;
    }

    append_worker_tag(id, buf, out, sizeof(out));
    write(write_fd, out, strlen(out) + 1);
  }

  close(read_fd);
  close(write_fd);
  exit(0);
}

int
main(int argc, char *argv[])
{
  if (argc != 2) {
    fprintf(2, "Usage: relay_plus <num_workers>\n");
    exit(1);
  }

  int n = atoi(argv[1]);
  if (n <= 0 || n > MAXWORKERS) {
    fprintf(2, "Number of workers must be between 1 and %d\n", MAXWORKERS);
    exit(1);
  }

 
  //   to_w[i][1]  = parent writes
  //   to_w[i][0]  = worker reads
  //   from_w[i][1]= worker writes
  //   from_w[i][0]= parent reads
  int to_w[MAXWORKERS + 1][2];
  int from_w[MAXWORKERS + 1][2];

  for (int i = 1; i <= n; i++) {
    pipe(to_w[i]);
    pipe(from_w[i]);
  }

  for (int i = 1; i <= n; i++) {
    int pid = fork();
    if (pid == 0) {
      // child: worker i
      // close all unrelated fds
      for (int j = 1; j <= n; j++) {
        // to_w: keep only to_w[i][0]
        if (j != i) close(to_w[j][0]);
        close(to_w[j][1]); // workers never write to to_w

        // from_w: keep only from_w[i][1]
        close(from_w[j][0]); // workers never read from from_w
        if (j != i) close(from_w[j][1]);
      }

      worker_loop(i, to_w[i][0], from_w[i][1]);
      // never returns
    }
  }

  // parent: close ends it doesn't use
  for (int i = 1; i <= n; i++) {
    close(to_w[i][0]);     // parent doesn't read to_w
    close(from_w[i][1]);   // parent doesn't write from_w
  }

  char cmd[MAXLINE];
  char mode[MAXLINE];
  char cur[MAXLINE];

  while (1) {
    // command
    printf("Enter command: ");
    memset(cmd, 0, sizeof(cmd));
    gets(cmd, sizeof(cmd));
    strip_newline(cmd);

    // When user typed :exit / :EXIT 
    if (strcmp(cmd, ":exit") == 0 || strcmp(cmd, ":EXIT") == 0) {
      for (int i = 1; i <= n; i++) {
        write(to_w[i][1], cmd, strlen(cmd) + 1);
      }
      break;
    }

    // get mode 
    enum mode_kind kind = 0;
    int k = 0;

    while (1) {
      printf("Mode (:all | :first k | :skip k): ");
      memset(mode, 0, sizeof(mode));
      gets(mode, sizeof(mode));
      strip_newline(mode);

      if (!parse_mode_line(mode, &kind, &k)) {
        printf("Error: malformed mode\n");
        continue;
      }

      if (kind == MODE_FIRST) {
        if (k < 1 || k > n) {
          printf("Error: worker %d does not exist\n", k);
          continue;
        }
      } else if (kind == MODE_SKIP) {
        if (k < 1 || k > n) {
          printf("Error: worker %d does not exist\n", k);
          continue;
        }
      }
      break;
    }

    // route through selected workers in order
    memset(cur, 0, sizeof(cur));
    strcpy(cur, cmd);

    if (kind == MODE_ALL) {
      for (int i = 1; i <= n; i++) {
        write(to_w[i][1], cur, strlen(cur) + 1);
        memset(cur, 0, sizeof(cur));
        read(from_w[i][0], cur, sizeof(cur));
      }
    } else if (kind == MODE_FIRST) {
      for (int i = 1; i <= k; i++) {
        write(to_w[i][1], cur, strlen(cur) + 1);
        memset(cur, 0, sizeof(cur));
        read(from_w[i][0], cur, sizeof(cur));
      }
    } else if (kind == MODE_SKIP) {
      for (int i = 1; i <= n; i++) {
        if (i == k) continue; // skipped worker receives nothing, reads nothing
        write(to_w[i][1], cur, strlen(cur) + 1);
        memset(cur, 0, sizeof(cur));
        read(from_w[i][0], cur, sizeof(cur));
      }
    }

    printf("Result: %s\n", cur);
  }

  // parent waits for workers
  for (int i = 0; i < n; i++) {
    wait(0);
  }

  for (int i = 1; i <= n; i++) {
    close(to_w[i][1]);
    close(from_w[i][0]);
  }

  exit(0);
}

